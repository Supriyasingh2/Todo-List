# Todoist-Clone
<div>
  <h3>
In the project directory, I cloned Todoist website, the top-ranked productivity app that helps millions of people organize work and life. 
  </h3>
</div>

## Tech Stack used:

<code><img height="40" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png"></code>
<code><img height="40" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/html/html.png"></code>
<code><img height="40" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/css/css.png"></code>
   
# ScreenShots


## `Login Page`
![Screenshot](https://github.com/Gaursafal/Todoist-Clone/blob/main/Screenshots/Screenshot%20(437).png)

## `Home Page`
![Screenshot](https://github.com/Gaursafal/Todoist-Clone/blob/main/Screenshots/Screenshot%20(438).png)

## `Dashboard Page`
![Screenshot](https://github.com/Gaursafal/Todoist-Clone/blob/main/Screenshots/Screenshot%20(439).png)


## Contributors

<h3>Safal Singh Gaur</h3> 👨‍ - <a href="https://github.com/Gaursafal">Safal Singh</a>

### Acknowledgments

<div>
  I take all the responsiblity for every single line of code.
</div>

## Deploy Link
`Deploy Link` - https://gaursafal.github.io/Todoist-Clone/


